import { useState } from 'react'
import { useEffect } from 'react'
import './styles.css'

// Através de pros conseguimos acessar as propriedades do "Home"
export function Card({ name, time }) {
  //desestruturação
  // const { name, time } = props

  // const props = {
  //   name: 'valor dinamico de nome',
  //   time: 'valor dinamico de tempo'
  // }

  const [githubPhoto, setGithubPhoto] = useState('')

  const fetchAPI = GitHubName => {
    fetch(`https://api.github.com/users/` + GitHubName)
      .then(response => response.json())
      .then(data => {
        setGithubPhoto(data.avatar_url)
      })
  }

  useEffect(() => {
    fetchAPI(name)
  }, [])

  return (
    <div className='card'>
      <img src={githubPhoto} alt={`Foto de ${name}`} className='imgCircle' />
      <strong>{name}</strong>

      <small>{time}</small>
    </div>
  )
}
